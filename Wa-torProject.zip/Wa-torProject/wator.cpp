/**
 * @file wator.cpp
 * @brief Simulation of predator-prey dynamics in the Wa-Tor world using SFML and OpenMP.
 * @author Tolu Ibiwoye
 * @date Created on THu Nov 23 2023
 * @version 1.0
 *
 * This file contains the implementation of the Wa-Tor simulation, which is an artificial life
 * program that simulates a simple predator-prey ecosystem. The simulation uses the SFML library
 * for rendering the graphical representation of the ecosystem and OpenMP for parallelizing
 * the simulation logic to improve performance on multi-core processors.
 */

// Commentary:
//
// The Wa-Tor simulation is a two-dimensional toroidal array representing an ocean
// populated by fish and sharks. The fish and sharks follow simple rules that dictate
// their movement, breeding, and feeding behavior, resulting in interesting patterns
// and dynamics that mimic real-world ecosystems.
//
// This implementation focuses on providing an efficient and parallelized version of
// the simulation, leveraging modern C++ features and libraries. It provides a visual
// window into the simulation's state at any given moment and allows observation of
// the complex interactions between the aquatic inhabitants of the Wa-Tor world.
//
// The primary objectives of this implementation are to:
// 1. Accurately model the rules of the Wa-Tor world.
// 2. Utilize concurrency to manage the simulation's state changes.
// 3. Render the state of the simulation to a window using SFML.
// 4. Experiment with different configurations and observe the outcomes.
//
// The program adheres to the principles of object-oriented design and strives for
// readability, maintainability, and performance. It is structured in a way that
// separates the simulation logic from the rendering and input management, facilitating
// ease of modifications and extensions.
//
// The implementation is licensed under the GNU General Public License, which grants
// freedom to use, share, and modify the software as long as all derivatives remain
// under the same license.
//
// This program is the result of collaborative efforts and is intended for educational
// purposes, demonstrating the concepts of cellular automata, agent-based modeling,
// and concurrent computing.
//

const int maxLock = 20;
const int maxDistribution = 50;
const int maxThread = 8; // Define the maximum number of threads
int THREADS = 4;
const int rows = 600;
const int columns = 600;
const int fish = -1;
const int shark = -1;
const int fishAdd = 1;
const int sharkAdd = 6;
const int sharkStarve = 2;
const int sharkEat = 1;
const int WindowXSize = 800;
const int WindowYSize = 600;
const int cellXSize = WindowXSize / rows;
const int cellYSize = WindowYSize / columns;
enum Direction
{
  North = 0,
  East = 1,
  South = 2,
  West = 3
};
enum CellType
{
  Ocean,
  Fish,
  Shark
};
struct Cell;
Cell getCell(int x, int y);
void setCell(int x, int y, Cell cell);

struct Cell
{
  CellType celltype;
  sf::Color color;
  int energy = 0;
  int turn = 0;
  int x;
  int y;
  bool hasMoved = false;
};

sf::RenderWindow window(sf::VideoMode(WindowXSize, WindowYSize), "SFML Wa-Tor world");
sf::RectangleShape display[rows][columns];
Cell cells[rows][columns];
drand48_data DecisionData[maxThread];
int durations[maxDistribution];

/*! 
 * \brief Get the fill color of a cell at given coordinates.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \return The color of the cell (Blue for Ocean, Green for Fish, Red for Shark).
 */
sf::Color getFillColor(int x, int y) { return cells[y][x].color; }

/*! 
 * \brief Determine if a cell is a Shark.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \return True if the specified cell is a Shark, false otherwise.
 */
bool isShark(int x, int y) { return cells[y][x].celltype == CellType::Shark; }

/*! 
 * \brief Check if a given cell contains a Fish.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \return True if the cell contains a Fish, false otherwise.
 */
bool isFish(int x, int y) { return cells[y][x].celltype == CellType::Fish; }

/*! 
 * \brief Ascertain whether a cell represents Ocean.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \return True if the cell represents an Ocean space, false otherwise.
 */
bool isOcean(int x, int y) { return cells[y][x].celltype == CellType::Ocean; }

/*! 
 * \brief Check if the cell has been processed in the current update cycle.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \return True if the cell has already been moved this turn, false otherwise.
 */
bool hasMoved(int x, int y) { return cells[y][x].hasMoved; }

/*! 
 * \brief Designate a cell at specified coordinates as a Shark.
 * \param x The x-coordinate of the target cell.
 * \param y The y-coordinate of the target cell.
 */
void setShark(int x, int y) {
  Cell cell;
  cell.celltype = CellType::Shark;
  cell.color = sf::Color::Red;
  cell.energy = sharkStarve;
  cell.turn = 0;
  cell.hasMoved = false;
  setCell(x, y, cell);
}

/*! 
 * \brief Assign the Fish cell type to a given cell.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 */
void setFish(int x, int y) {
  Cell cell;
  cell.celltype = CellType::Fish;
  cell.color = sf::Color::Green;
  cell.turn = 0;
  cell.hasMoved = false;
  setCell(x, y, cell);
}

/*! 
 * \brief Set a cell to represent Ocean.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 */
void setOcean(int x, int y) {
  Cell cell;
  cell.celltype = CellType::Ocean;
  cell.color = sf::Color::Blue;
  setCell(x, y, cell);
}

/*! 
 * \brief Retrieve a cell's properties by its coordinates.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \return A copy of the Cell object at the given coordinates.
 */
Cell getCell(int x, int y) {
  return cells[y][x];
}

/*! 
 * \brief Update the cell at given coordinates with a new Cell object.
 * \param x The x-coordinate of the cell.
 * \param y The y-coordinate of the cell.
 * \param cell The new Cell object to place in the specified location.
 */
void setCell(int x, int y, Cell cell) {
  cell.x = x;
  cell.y = y;
  cells[y][x] = cell;
}

/*! 
 * \brief Assigns neighboring cells to the provided array based on the central cell's location.
 * \param x X-coordinate of the central cell.
 * \param y Y-coordinate of the central cell.
 * \param [out] list Array to fill with the neighboring cells.
 * \details Populates an array with the cells directly adjacent (north, south, east, west) to the specified central cell.
 */
void setNeighbours(int x, int y, Cell list[])
{
  int north = ((y - 1) + rows) % rows;
  int south = (y + 1) % rows;   // no braces cause segfault
  int east = (x + 1) % columns; // no braces cause segfault
  int west = ((x - 1) + columns) % columns;
  list[0] = getCell(x, north);
  list[1] = getCell(east, y);
  list[2] = getCell(x, south);
  list[3] = getCell(west, y);
}

/*! 
 * \brief Executes the movement logic for a shark cell.
 * \param x X-coordinate of the shark cell.
 * \param y Y-coordinate of the shark cell.
 * \details Moves the shark in the simulation, allowing it to eat fish or move to an empty space, and handles breeding and starvation.
 */
void sharkMove(int x, int y)
{
  Cell shark = getCell(x, y);
  Cell neighbours[4];
  setNeighbours(x, y, neighbours);
  long location;
  lrand48_r(&DecisionData[omp_get_thread_num()], &location);
  location = location % 4;
  shark.energy--;
  shark.turn++;
  int x2, y2;
  // Hunting Fish
  for (int i = 0; i < 4; i++)
  {
    x2 = neighbours[location].x;
    y2 = neighbours[location].y;
    if (isFish(x2, y2))
    {
      shark.hasMoved = true;
      shark.energy += sharkEat;
      setOcean(x, y);
      break;
    }
    if (!shark.hasMoved)
    {
      location = (location + 1) % 4;
    }
  }

  // No fish found
  // Finding free space to move
  if (!shark.hasMoved)
  {
    for (int i = 0; i < 4; ++i)
    {
      int x2 = neighbours[location].x;
      int y2 = neighbours[location].y;
      if (isOcean(x2, y2))
      {
        shark.hasMoved = true;
        setOcean(x, y);
        break;
      }
      if (!shark.hasMoved)
      {
        location = (location + 1) % 4;
      }
    }
  }

  if (shark.hasMoved)
  {
    if (shark.turn >= sharkAdd)
    {
      shark.turn = 0;
      setShark(x, y);
    }

    if (shark.energy < 0)
    {
      setOcean(x2, y2);
    }
    else
    {
      setCell(x2, y2, shark);
    }
  }
  else
  {
    // Sharks still starve if they don't move
    if (shark.energy < 0)
    {
      setOcean(x, y);
    }
    else
    {
      setCell(x2, y2, shark);
    }
  }
}

/*! 
 * \brief Manages the movement behavior for a fish cell.
 * \param x X-coordinate of the fish cell.
 * \param y Y-coordinate of the fish cell.
 * \details Moves the fish in the simulation, allowing it to swim to an empty cell and handles its breeding cycle.
 */

 void fishMove(int x, int y)
{
  Cell fish = getCell(x, y);
  Cell neighbours[4];
  setNeighbours(x, y, neighbours);
  long location;
  lrand48_r(&DecisionData[omp_get_thread_num()], &location);
  location = location % 4;
  for (int i = 0; i < 4; i++)
  {
    int x2 = neighbours[location].x;
    int y2 = neighbours[location].y;
    if (isOcean(x2, y2))
    {
      fish.turn = fish.turn + 1;
      fish.hasMoved = true;
      setOcean(x, y);
      if (fish.turn == fishAdd)
      {
        fish.turn = 0;
        setFish(x, y);
      }
      setCell(x2, y2, fish);
      break;
    }
    if (!fish.hasMoved)
    {
      location = (location + 1) % 4;
    }
  }
}

/*! \fn poll
    \brief Wrapper function around SFML's poll event
*/
void poll()
{
  sf::Event event;
  while (window.pollEvent(event))
  {
    if (event.type == sf::Event::Closed)
      window.close();
  }
}

/*! \fn move
    \param x - The x co-ordinate of the cell
    \param y - The y co-ordinate of the cell
    \brief Checks that the Cell at the x, y co-ordinate is a movable fish or shark (that hasn't moved this game loop)
    and calls into their respective move functions
*/
void move(int x, int y)
{
  if (isFish(x, y) && !hasMoved(x, y))
  {
    fishMove(x, y);
  }
  else if (isShark(x, y) && !hasMoved(x, y))
  {
    sharkMove(x, y);
  }
}

/*! \fn move
    \brief Thread-safe move function that loops over the entire grid (split by the current number of threads) and calls into
    the single-cell move function per cell.
*/
void move()
{
#pragma omp parallel for collapse(2)
  for (int y = 0; y < rows; ++y)
  {
    for (int x = 0; x < columns; ++x)
    {
      move(x, y);
      display[y][x].setFillColor(getFillColor(x, y));
    }
  }
}

/*! \fn draw
    \brief Wrapper function around SFML's drawing algorithm
*/
void draw()
{
  window.clear(sf::Color::Black);
  for (int y = 0; y < rows; ++y)
  {
    for (int x = 0; x < columns; ++x)
    {
      window.draw(display[y][x]);
    }
  }
  window.display();
}

/*! \fn initialize
    \brief Function that initializes the game state, including seeding the random number generations, setting the
    total number of threads, preparing the mutex locks and thread-safe random buffers, as well as building and drawing
    the initial grid. It does a lot but it only does it once.
*/
void initialize()
{
  srand48(0);
  omp_set_num_threads(THREADS);
  // Remove the reference to locks since Semaphore-related code was removed
  for (int y = 0; y < rows; ++y)
  {
    for (int x = 0; x < columns; ++x)
    {
      display[y][x].setSize(sf::Vector2f(cellXSize, cellYSize));
      display[y][x].setPosition(x * cellXSize, y * cellYSize);
      setOcean(x, y);
      int id = y * 1 - +x;
      if (id % 18 == 0)
      {
        setShark(x, y);
      }
      else if (id % 10 == 0)
      {
        setFish(x, y);
      }
      display[y][x].setFillColor(getFillColor(x, y));
    }
  }
  draw();
}

/*! \file Wa-Tor Simulation
    \brief Implementation of the Wa-Tor simulation concurrently using SFML for graphics and OpenMP for concurrency
*/

/*! \fn main
    \brief The main application entry point
*/
int main()
{
  int threadCounts[] = {1, 2, 4, 8}; // Define the thread counts to test
  int numTests = 4;                  // Number of thread counts to test

  for (int i = 0; i < numTests; ++i)
  {
    printf("Switching to %d Threads...\n", threadCounts[i]); // Print the message

    THREADS = threadCounts[i]; // Set the number of threads for this test

    initialize(); // Initialize the simulation grid and other parameters
    int generation = 0;
    while (window.isOpen() && generation < maxDistribution)
    {

      poll(); // Check for SFML events like window closure
      auto start = std::chrono::steady_clock::now();
      move(); // Execute the simulation logic, updating the state of each cell
#pragma omp parallel for collapse(2)
      for (int y = 0; y < rows; ++y)
      {
        for (int x = 0; x < columns; ++x)
        {
          cells[x][y].hasMoved = false; // Reset the "hasMoved" flag for each cell
        }
      }
      auto end = std::chrono::steady_clock::now();
      auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
      // Drawing takes about 5x more than anything else and can't be called from multiple threads consistently
      draw(); // Render the updated state of the simulation grid
      printf("Thread Count: %d, Generation %d Duration: %ld\n", THREADS, generation, duration);
      durations[generation] = duration;
      generation++;
    }
  }

  return 0;
}