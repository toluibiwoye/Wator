var searchData=
[
  ['threads_101',['THREADS',['../wator_8cpp.html#adb114dea5ac91e6786143adc010dc526',1,'wator.cpp']]],
  ['turn_102',['turn',['../struct_cell.html#a7fb5e139c7a538e002179de8ef844b89',1,'Cell']]]
];
