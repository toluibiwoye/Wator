var searchData=
[
  ['threads_48',['THREADS',['../wator_8cpp.html#adb114dea5ac91e6786143adc010dc526',1,'wator.cpp']]],
  ['turn_49',['turn',['../struct_cell.html#a7fb5e139c7a538e002179de8ef844b89',1,'Cell']]]
];
