var searchData=
[
  ['hasmoved_92',['hasMoved',['../struct_cell.html#a3957767a02817eb3768fda74ac6bbc71',1,'Cell']]]
];
