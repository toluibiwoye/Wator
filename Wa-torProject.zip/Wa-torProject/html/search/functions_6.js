var searchData=
[
  ['poll_72',['poll',['../wator_8cpp.html#aabfa6a53da249dcd1b75b6022f163fd7',1,'wator.cpp']]]
];
