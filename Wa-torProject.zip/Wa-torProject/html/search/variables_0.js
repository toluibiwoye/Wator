var searchData=
[
  ['cells_80',['cells',['../wator_8cpp.html#ada84966386ae4e53cc5de995e50ad1b4',1,'wator.cpp']]],
  ['celltype_81',['celltype',['../struct_cell.html#a05c66af92d00442e9f7e23447d96b74d',1,'Cell']]],
  ['cellxsize_82',['cellXSize',['../wator_8cpp.html#a7879482615ac71ba4792918e8ac97974',1,'wator.cpp']]],
  ['cellysize_83',['cellYSize',['../wator_8cpp.html#ac89bb2757f16a08bba8da53ec1f47754',1,'wator.cpp']]],
  ['color_84',['color',['../struct_cell.html#a90254dad70cad14734c9bf3ce98ebc04',1,'Cell']]],
  ['columns_85',['columns',['../wator_8cpp.html#ae68a25c0023d8b777603c0f8b05e591a',1,'wator.cpp']]]
];
