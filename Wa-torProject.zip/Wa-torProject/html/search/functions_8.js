var searchData=
[
  ['window_79',['window',['../wator_8cpp.html#a9dfe94873f2f48614918431af8426f79',1,'wator.cpp']]]
];
