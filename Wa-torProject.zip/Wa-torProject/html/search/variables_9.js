var searchData=
[
  ['windowxsize_103',['WindowXSize',['../wator_8cpp.html#ac7ab5ee55dcd44ef05c33e2c710137f3',1,'wator.cpp']]],
  ['windowysize_104',['WindowYSize',['../wator_8cpp.html#accf8a62be256e8e1d7f915d79e218e6f',1,'wator.cpp']]]
];
