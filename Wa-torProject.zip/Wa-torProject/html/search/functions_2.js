var searchData=
[
  ['getcell_63',['getCell',['../wator_8cpp.html#aba4511901453580d26f963aef5865967',1,'wator.cpp']]],
  ['getfillcolor_64',['getFillColor',['../wator_8cpp.html#af43b983334b31234c08291ad553204b3',1,'wator.cpp']]]
];
