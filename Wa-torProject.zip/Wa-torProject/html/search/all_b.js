var searchData=
[
  ['readme_2emd_34',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rows_35',['rows',['../wator_8cpp.html#a157b993c60eb39741c69aeb616a11e70',1,'wator.cpp']]]
];
