var searchData=
[
  ['initialize_66',['initialize',['../wator_8cpp.html#a91098fa7d1917ce4833f284bbef12627',1,'wator.cpp']]],
  ['isfish_67',['isFish',['../wator_8cpp.html#aa0ba3a3ab7e3bcaedfab9325a36bcd3f',1,'wator.cpp']]],
  ['isocean_68',['isOcean',['../wator_8cpp.html#a16fc37e21c1d3338302016f868521b8a',1,'wator.cpp']]],
  ['isshark_69',['isShark',['../wator_8cpp.html#a9fe5b5e9fa0f76f462326b215c4d0a6b',1,'wator.cpp']]]
];
