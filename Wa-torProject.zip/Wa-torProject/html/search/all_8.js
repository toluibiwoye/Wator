var searchData=
[
  ['north_31',['North',['../wator_8cpp.html#a224b9163917ac32fc95a60d8c1eec3aaaaeb9634ef4d4fd4a5297ada06f89c3fe',1,'wator.cpp']]]
];
