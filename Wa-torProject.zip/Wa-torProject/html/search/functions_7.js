var searchData=
[
  ['setcell_73',['setCell',['../wator_8cpp.html#a46e679205f7cf7fed7e38ea4d6f2a5dc',1,'wator.cpp']]],
  ['setfish_74',['setFish',['../wator_8cpp.html#a8fa730df063d32510e98a525261fe55b',1,'wator.cpp']]],
  ['setneighbours_75',['setNeighbours',['../wator_8cpp.html#a1222fb80b0c10b59aca6e1d4cac09c3c',1,'wator.cpp']]],
  ['setocean_76',['setOcean',['../wator_8cpp.html#a18faf1ad0560f5706dd8e913c464a8b7',1,'wator.cpp']]],
  ['setshark_77',['setShark',['../wator_8cpp.html#ae62e5b8d47f08def059ade12e6a95fc5',1,'wator.cpp']]],
  ['sharkmove_78',['sharkMove',['../wator_8cpp.html#a0c02514ac8a1f6fc9519412e6a40b11d',1,'wator.cpp']]]
];
