var searchData=
[
  ['east_13',['East',['../wator_8cpp.html#a224b9163917ac32fc95a60d8c1eec3aaa66183dce5a3b8d48fbdfe1f8ede7fcc2',1,'wator.cpp']]],
  ['energy_14',['energy',['../struct_cell.html#ae12c9b75a66158c35bfacf482221499b',1,'Cell']]]
];
