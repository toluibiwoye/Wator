var struct_cell =
[
    [ "celltype", "struct_cell.html#a05c66af92d00442e9f7e23447d96b74d", null ],
    [ "color", "struct_cell.html#a90254dad70cad14734c9bf3ce98ebc04", null ],
    [ "energy", "struct_cell.html#ae12c9b75a66158c35bfacf482221499b", null ],
    [ "hasMoved", "struct_cell.html#a3957767a02817eb3768fda74ac6bbc71", null ],
    [ "turn", "struct_cell.html#a7fb5e139c7a538e002179de8ef844b89", null ],
    [ "x", "struct_cell.html#ac008158796a0bfdf37be2f26eff651ef", null ],
    [ "y", "struct_cell.html#ab99a0cead05c6b8129ddf3231b11c1ad", null ]
];