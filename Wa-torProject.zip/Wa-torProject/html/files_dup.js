var files_dup =
[
    [ "wator.cpp", "wator_8cpp.html", "wator_8cpp" ]
];