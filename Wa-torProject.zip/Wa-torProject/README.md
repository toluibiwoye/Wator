# Wa-Tor

## 1. Project Licence
This project is licensed under the [MIT License](https://spdx.org/licenses/MIT.html).
[Github Link](https://github.com/toluibiwoye/Wa-tor.git).

## 2. Authors of Project
- **Student:** Tolu Ibiwoye
- **Lecturer:** Joseph Kehoe
- **Student Number:** C00243451
- **Institution:** South East Technological University
- **Date:** 23/11/2023

# How to install project
**Run - `./watorsim`**
**make- `make`**


## List of any required Libraries, platform issues, etc.:

**Linux** - Environment
**g++** - Compiler
**vs code** - Editor
**make** - For creating MakeFile
**gdb** - Debugger
**doxygen** - Code documentation

## List of files and what they contain:
 **wator.cpp** - the main project class.
 **MakeFile** - compilies the program.
 **README** - information about the project file.